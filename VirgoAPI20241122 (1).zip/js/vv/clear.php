<?php
opcache_reset();
?>